//#include <stdio.h>
//#include <stdlib.h>
//
//#include "Header.h"
//
//
//void Month(char ** month)
//{
//    int grade;
//
//    time_t currentTime;
//
//    time(&currentTime);
//
//    struct tm *myTime = localtime(&currentTime);
//
////    if((myTime->tm_mon) == 0){
////
////        month = "Jan";
////    }
////
//
//    grade = myTime->tm_mon;
//
//
//        switch(grade)
//        {
//
//            case 0 : // Osova vzdalenost bubnu (mm)
//            *month = "Leden";
//            break;
//
//            case 1 : // Osova vzdalenost bubnu (mm)
//            *month = "Unor";
//            break;
//
//            case 2 : // Osova vzdalenost bubnu (mm)
//            *month = "Brezen";
//            break;
//
//            case 3 : // Osova vzdalenost bubnu (mm)
//            *month = "Duben";
//            break;
//
//            case 4 : // Osova vzdalenost bubnu (mm)
//            *month = "Kveten";
//            break;
//
//            case 5 : // Osova vzdalenost bubnu (mm)
//            *month = "Cerven";
//            break;
//
//            case 6 : // Osova vzdalenost bubnu (mm)
//            *month = "Cervenec";
//            break;
//        }
//
//
//
//        printf("Mesic je %s \n", (*month));
//}
